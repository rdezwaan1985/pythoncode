#!/bin/bash

# download dependencies
pip install -r requirements.txt
# run app
python app.py
